# Rebounce Applied AI and Analytics Codes

Author: Samreen Kauser

My notes and practice notebooks from the Rebounce Applied AI and Analytics course.

## Folders

- **01_Python_Basics** - data types, strings, lists, dictionaries, conditionals, loops, functions
- **02_NumPy** - NumPy arrays practice (Session 5)
- **03_Pandas** - loading, selecting, filtering, cleaning, grouping and merging data (Sessions 6 to 8)
- **04_OOP** - classes, objects, inheritance, polymorphism, and pip basics
- **05_Assignments** - Python 101 problem set, Python 201 expense tracker, Python 301 retail sales analysis

Note: the Pandas notebooks read `session6_policy_data.csv` and `session6_region_lookup.csv`. Keep those files next to the notebooks when running them.
